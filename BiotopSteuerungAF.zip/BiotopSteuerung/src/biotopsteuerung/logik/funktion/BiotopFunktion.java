package biotopsteuerung.logik.funktion;

/**
 * Soll-Ist-Vergleich
 * Generiert Aktion f�r die Aktuere 
 * 
 * @author Thomas
 *
 */
public class BiotopFunktion {

	
}
