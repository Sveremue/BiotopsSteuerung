package biotopsteuerung.logik.data;

public class Aktion {

	private int diffusorLaufzeitInSec;
	private int luefterLaufzeitInSec;
	private boolean lichtAn;
	
}
