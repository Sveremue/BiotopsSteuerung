package biotopsteuerung.logik.schnittstelle;

public class GOIPOutputSchnittstelle {

}
