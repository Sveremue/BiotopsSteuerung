package biotopsteuerung.logik.datenbank;

public class PreparedStatementConstants {
	//TODO relativ machen
		public static final String PREPSTMT_VERZEICHNIS_PFAD = "E:\\Proggen\\Projekte\\Terarium\\Terarium\\src\\PreparedStatement\\";
		
		//Select
		public static final String SELECT_SOLLWERT_PREPSTMT_ID = "select_sollwert_prepstmt_id";
		
		//Update
		public static final String UPDATE_SOLLWERT_SATZ_PREPSTMT_ID = "update_sollwert_satz_prepstmt_id";
		
		//Datatyps
		public static final String DATATYP_INTEGER = "INT";
		public static final String DATATYP_STRING= "STRING";
		public static final String DATATYP_DOUBLE= "DOUBLE";
		public static final String DATATYP_DATE= "DATE";
		public static final String DATATYP_DATATYP_MARK= "Datatypes";
}
