SELECT * FROM SollDaten WHERE RelL = ?
;
Datatypes
INT