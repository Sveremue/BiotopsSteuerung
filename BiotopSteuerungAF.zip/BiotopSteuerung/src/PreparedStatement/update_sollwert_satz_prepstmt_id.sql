INSERT INTO SollDaten (Temp, RelL)
VALUES
(?, ?)
Datatypes
DOUBLE,INT