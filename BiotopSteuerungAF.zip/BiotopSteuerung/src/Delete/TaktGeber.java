package Delete;

import java.util.Observable;
import java.util.concurrent.ThreadLocalRandom;

import biotopsteuerung.logik.data.UmgebungsDaten;

public class TaktGeber extends Observable {

	

}
